firewall {
	deny
	allow port: "ssh"
	allow port: "http"
	allow port: "https"
}
