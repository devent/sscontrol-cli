hostname { set "ubuntutest" }
