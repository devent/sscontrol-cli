package com.anrisoftware.sscontrol.resources
profile "ubuntu_10_04", {
	system {
		install_command "${prefix}/usr/bin/aptitude update && ${prefix}/usr/bin/aptitude install"
		restart_command "${prefix}/sbin/restart"
	}
	hostname { configuration_directory "${prefix}/etc" }
	hosts { configuration_directory "${prefix}/etc" }
}
