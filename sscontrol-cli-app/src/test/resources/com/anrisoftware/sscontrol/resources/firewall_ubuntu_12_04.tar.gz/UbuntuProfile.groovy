profile "ubuntu_12_04", {
    hostname { 
        install_command "${prefix}/usr/bin/aptitude update && ${prefix}/usr/bin/aptitude install"
        restart_command "${prefix}/etc/init.d/hostname restart"
        configuration_directory "${prefix}/etc"
    }
	hosts {
        configuration_directory "${prefix}/etc"
	}
    firewall { 
        service "ufw" 
        install_command "${prefix}/usr/bin/aptitude update && ${prefix}/usr/bin/aptitude install"
        ufw_command "${prefix}/usr/sbin/ufw"
    }
}
