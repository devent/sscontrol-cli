hosts {
	ip "192.168.0.100" host "ubuntutest.com" alias "ubuntutest"
    ip "192.168.0.110" host "www.ubuntutest.com"
}
