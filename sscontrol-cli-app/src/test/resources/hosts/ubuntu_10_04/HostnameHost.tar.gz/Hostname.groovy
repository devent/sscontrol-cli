package hosts.ubuntu_10_04

hostname { //.
	set "ubuntu" //.
}
