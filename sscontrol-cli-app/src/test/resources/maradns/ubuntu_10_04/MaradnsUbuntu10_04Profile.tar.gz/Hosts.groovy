package maradns.ubuntu_10_04

hosts {
	ip "192.168.0.100" host "ubuntu.ubuntutest.com" alias "ubuntu" //.
}
