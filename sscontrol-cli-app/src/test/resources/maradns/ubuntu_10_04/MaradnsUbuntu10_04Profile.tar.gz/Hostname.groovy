package maradns.ubuntu_10_04

hostname { //.
	set "ubuntu" //.
}
